# Savvy Coders Student Showcase
## First Group Project

Today, you're going to help create a Student Showcase for you and your classmates. This will be a responsively-designed site that features all of your smiling faces and insightful portfolio websites. To get started, `git clone` this repository.

Be sure to follow our modified GitHub workflow for all pull requests. Good luck!

Example - John Cotton
+ [Follow on Github](https://github.com/thejohncotton)

Keri Hekdman
+ [Follow on Github]()

Chris Williams
+ [Follow on Github]()

Larry Hudson
+ [Follow on Github]()

Dante Cruz
+ [Follow on Github]()

Nick Guertin
+ [Follow on Github](https://github.com/NickGuertin)

Christopher Chaney
+ [Follow on Github]()

Joseph Dockery
+ [Follow on Github]()

Caleb Lowe
+ [Follow on Github]()

Rakesha McIntryre
+ [Follow on Github]()

Luz Cortes
+ [Follow on Github]()

Jamiecia Love
+ [Follow on Github]()

Jasmine Thomas
+ [Follow on Github]()

T'nea Mayweather
+ [Follow on Github]()

Alexandria Strider
+ [Follow on Github]()

Carisa Brown
+ [Follow on Github]()

Alex French
+ [Follow on Github]()

Cheryl Zuckerman
+ [Follow on Github]()

Quintez Martin
+ [Follow on Github]()

Darrell Haire
+ [Follow on Github]()
